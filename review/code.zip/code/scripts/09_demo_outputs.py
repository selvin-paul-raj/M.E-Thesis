"""Module 2 demo / output evidence (CPU only, no torch needed).

Uses the cached multilingual-e5-small embeddings in results/cache/ for the dense retriever,
so it runs on any laptop without downloading the model.
  1. dataset statistics
  2. Tanglish normaliser: before / after for sample queries (rules vs ITRANS) + latency
  3. top-5 retrieved documents for example queries, raw vs rule-normalised, dense and char-3 BM25
  4. re-computes MRR@10 / Recall@10 for selected query sets and checks them against main_results.csv
Usage:  python scripts/09_demo_outputs.py            (run from the code/ folder)
"""
import sys, pathlib, time, json
import numpy as np, pandas as pd
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from tanglish_rag.normalise import normalise
from tanglish_rag.retrievers import BM25, char_ngrams, word_tokens, topk, topk_positive, rrf
from tanglish_rag.metrics import per_query

cache = pathlib.Path("results/cache/multilingual-e5-small")
corpus = pd.read_json("data/corpus.jsonl", lines=True)
q = pd.read_json("data/queries.jsonl", lines=True)
ids = corpus.doc_id.tolist(); texts = corpus.text_ta.tolist()
COL = {"en": "query_en", "ta": "query_ta", "rom": "query_ta_romanized", "cm": "query_ta_codemix",
       "rom_itrans": "rom_itrans", "rom_rules": "rom_rules", "cm_itrans": "cm_itrans", "cm_rules": "cm_rules"}

def hr(t): print("\n" + "=" * 78 + "\n" + t + "\n" + "=" * 78)

hr("1. DATASET")
print(f"documents (Tamil corpus)     : {len(corpus)}")
print(f"queries per form             : {len(q)}")
print(f"query sets                   : {', '.join(COL)}")
cc = corpus.text_ta.str.len()
print(f"doc length chars mean/median/max : {cc.mean():.1f} / {cc.median():.0f} / {cc.max()}")
print(f"queries per document (mean)  : {len(q) / q.doc_id.nunique():.2f}")

hr("2. TANGLISH NORMALISER (romanised Tamil -> Tamil script; English tokens kept)")
samples = ["scholarship ku last date enna?", "Israel Hamas conflict ku yaar responsible",
           "Vadakku maagaana paadasaalai seerudai neelam korikkai",
           "thakkudhalil Colombia raanuva thiraigal uyirizhappu",
           "Muthalaq thadai masoda Rajyasabha"]
for s in samples:
    print(f"\n  input  : {s}\n  rules  : {normalise(s, 'rules')}\n  ITRANS : {normalise(s, 'itrans')}")
rom = q.query_ta_romanized.tolist()[:200]
for s in rom: normalise(s, "rules")  # warm the language-ID cache
t = time.perf_counter(); [normalise(s, "rules") for s in rom]; dt = (time.perf_counter() - t) / len(rom) * 1000
print(f"\n  rules normalisation latency: {dt:.3f} ms/query (mean over 200 romanised queries, warm cache)")

hr("3. TOP-5 RETRIEVAL FOR EXAMPLE QUERIES (Tamil corpus)")
D = np.load(cache / "docs_ta.npy")
Q = {s: np.load(cache / f"{s}.npy") for s in ("en", "ta", "rom", "rom_rules", "cm")}
bmc = BM25(texts, char_ngrams); bmw = BM25(texts, word_tokens)
pos = {qid: i for i, qid in enumerate(q.qid)}
for qid in ["q01571", "q00660", "q00114"]:  # the three report examples (results/examples.json)
    if qid not in pos: continue
    i = pos[qid]; gold = q.doc_id[i]; g = ids.index(gold)
    print(f"\n--- {qid}   gold doc #{g}: {texts[g][:70]}...")
    for s in ("en", "ta", "rom", "rom_rules", "cm"):
        qt = q[COL[s]][i]
        r_d = topk(D @ Q[s][i], 10); r_c = topk_positive(bmc.scores(qt), 10)
        rk = lambda r: (list(r).index(g) + 1) if g in r else "-"
        print(f"  [{s:9s}] {qt}")
        fmt = lambda r: " ".join(("*" if d == g else "") + str(int(d)) for d in r[:5]) or "(no lexical match)"
        print(f"      dense top-5 : {fmt(r_d):32s} gold rank {rk(r_d)}   top-1: {texts[int(r_d[0])][:38]}...")
        print(f"      char3 top-5 : {fmt(r_c):32s} gold rank {rk(r_c)}")
    print("      (* = gold document; numbers are corpus document indices)")

hr("4. RE-COMPUTE METRICS FROM SCRATCH AND CHECK AGAINST results/main_results.csv")
ref = pd.read_csv("results/main_results.csv")
checks = [("rom", "Dense-e5"), ("rom_rules", "Dense-e5"), ("rom", "BM25-char3"), ("rom_rules", "BM25-char3"),
          ("en", "Dense-e5"), ("en", "Hybrid-RRF")]
print(f"  {'query set':10s} {'retriever':11s} {'MRR@10':>8s} {'R@10':>7s} {'reported MRR@10':>16s}  match")
for s, r in checks:
    Qs = Q.get(s) if s in Q else np.load(cache / f"{s}.npy")
    rows = []
    for i, (qt, gold) in enumerate(zip(q[COL[s]], q.doc_id)):
        r_d = topk(D @ Qs[i])
        if r == "Dense-e5": idx = r_d
        elif r == "BM25-char3": idx = topk_positive(bmc.scores(qt))
        else: idx = rrf([topk_positive(bmw.scores(qt)), r_d])
        rows.append(per_query([ids[j] for j in idx[:10]], gold))
    df = pd.DataFrame(rows); m = df["MRR@10"].mean(); r10 = df["R@10"].mean()
    rep = ref[(ref.corpus == "ta") & (ref.query_set == s) & (ref.retriever == r)]["MRR@10"].iloc[0]
    print(f"  {s:10s} {r:11s} {m:8.3f} {r10:7.3f} {rep:16.3f}  {'OK' if abs(m - rep) < 1e-4 else 'DIFF'}", flush=True)
print("\nDone.")
